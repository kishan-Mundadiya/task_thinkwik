const express = require('express');
const router = express.Router();
const middleware = require('../services/middleware')

const TestController = require('../controllers/TestController');

router.post('/user/type',middleware, TestController.getUserByType);
router.post('/signin', middleware, TestController.login);
router.post('/signup',middleware, TestController.usersRegistration);
router.post('/user/get', TestController.getUserData);

module.exports = router;