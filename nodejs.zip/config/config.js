/*
------------------------------------
Ajay Mithapara (7623038598)
------------------------------------
*/

module.exports = {
 port: 3000,
 JWT_SECRET_TOKEN : 'Dfbbug_ngrnkl-12dlkng5@#vk'
}
