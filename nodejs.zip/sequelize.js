const Sequelize = require('sequelize');
const Op = Sequelize.Op;

const userTable = require('./models/users');
const sequelize = new Sequelize('officeinnovation', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
});

const users = userTable(sequelize, Sequelize)
try {
    sequelize.authenticate();
    console.log("connected successfully..");
} catch (error) {
    console.log("something went wrong", error);
}


sequelize.sync({alter:true})
    .then(() => {
        console.log("connected to database successfully");
    });

module.exports = {
     users
}