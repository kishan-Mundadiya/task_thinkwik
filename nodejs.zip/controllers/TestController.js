const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const saltRounds = 10;
const models = require('../sequelize');
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const config = require('../config/config');
const { uuid } = require('uuidv4');
const { response } = require('express');

module.exports = {
    async test(req, res) {
        try {
            let params = req.body;
            return res.json({ 'status': true });
        } catch (error) {
            console.log('>>>>>> Catch Error :: ', error);
            return res.json({ 'status': false, 'statusCode': -1 });
        }
    },
    async login(req, res) {
        let params = req.body;
        let response = { status: false, statusCode: -1 }
        let jwtKey = config.JWT_SECRET_TOKEN;
        if (params.name && params.name.trim() != "" && params.password && params.password.trim() != "") {

            let data = await models['users'].findAll({
                where: {
                    [Op.or]: [
                        { 'email': params.name },
                        { 'phone': params.name }
                    ]
                },
            });
            let isValid  = data.length > 0 ? true : false;
            if (isValid) {
                let userData = data[0]
                let isMatch = await bcrypt.compare(params.password, userData.password)
                if (isMatch) {
                    let jwtToken = jwt.sign({
                        time: Date(),
                        userId: params.name,
                    }, jwtKey, { expiresIn: '3h' });

                    response = { status: true, 'jwtToken': jwtToken }
                } else {
                    response = { status: false, statusCode: 1 }
                }

            } else {
                response = { status: false, statusCode: 2 }
            }
        }

        console.log("------login------", JSON.stringify(response));
        return res.json(response)
    },

    async usersRegistration(req, res) {
        let params = req.body;
        let response = { status: false, statusCode: -1 };
        if (params.name && params.name.trim() != "" && params.password && params.password.trim() != "" && params.email && params.email.trim() != "" && params.phone && params.phone.trim() != "" ) {

            let data = await models['users'].findAll({
                where: {
                    [Op.or]: [
                        { 'email': params.email },
                        { 'phone': params.phone }
                    ]
                },
                attributes: ['name', 'email', 'phone']
            });
            let isExist = data.length > 0 ? true : false;
            if (!isExist) {
                let userType = ['admin','user','manager','superAdmin']
                let encryptPassword = await bcrypt.hash(params.password, saltRounds);
                let randomType = userType[Math.floor(Math.random() * userType.length)];
                await models['users'].create({
                    'user_id': uuid(),
                    'name': params.name,
                    'phone': params.phone,
                    'email': params.email,
                    'password': encryptPassword,
                    'age':Math.floor(Math.random() * 100),
                    'type':userType[randomType]
                })
                response = {status:true}
            } else {
                response = { status: false, statusCode: 1 }
            }
        }
        return res.json(response)
    },

    async getUserData(req, res) {
        let params = req.body;
        let response = { status: false, statusCode: -1 };
        console.log("==>>", params.limit != undefined && Number.isInteger(params.limit) && params.limit > 0);
        if (params.limit != undefined && Number.isInteger(params.limit) && params.limit > 0 && params.offset != undefined &&
            Number.isInteger(params.offset) && params.offset >= 0) {

               
                let whereOpts = {};
                if(params.search != undefined && params.search != "") {
                    whereOpts = {
                        [Op.or] : [
                            {
                            name:{
                                [Op.like] : `%${params.search}%`
                            }
                        },
                        {
                            email : {
                                [Op.like] : `%${params.search}%`
                            } 
                        }
                    ]
                    }
                } 
                sortBy = 'ASC'
                if(params.sort != undefined && params.sort != "" && params.sort == -1){
                    sortBy = 'DESC'
                }
                
                let data = await models['users'].findAll({
                    where: whereOpts,
                    offset: params.offset, 
                    limit: params.limit,
                    order: [
                        ['name', sortBy]
                    ],
                });
                let dataCount = await models['users'].count({
                    where: whereOpts,
                });
                response = {status:true, data:data,count:dataCount}
                // console.log("==>query result::",JSON.stringify(data));
                
        }
        console.log("==>>response:::", JSON.stringify(response));
        return res.json(response)
    },

    async getUserByType(req,res){
        let users = await models['users'].findAll({
            group:['type'],
            attributes: [[Sequelize.fn('COUNT', 'users.type'),'count'], 'type'],
            order: [
                ['type', 'ASC']
            ],
        })

        return res.json({'status':true,'data':users})
        // console.log("==>data<<<<<<",JSON.stringify(users));
    }

}